//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GBReader.rsrc.rc
//
#define IDD_DIALOG1                     101
#define IDR_MENU1                       134
#define IDC_ABOUT                       1002
#define IDC_OPENFILE                    1003
#define IDC_MEMO                        1058
#define IDC_LIST                        1060
#define IDC_LOADFILE                    40001
#define IDC_EXIT                        40002
#define IDC_MENUABOUT                   40004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         40005
#define _APS_NEXT_CONTROL_VALUE         1061
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
