#include "GBReader.h"

//======================Handles================================================//
HINSTANCE hInst; // main function handler
HWND hList=NULL;
//====================MAIN=DIALOG==========================================//
BOOL CALLBACK DialogProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message) // what are we doing ?
	{ 	 
		// This Window Message is the heart of the dialog //
		//================================================//
		case WM_INITDIALOG: 
		{
			LVCOLUMN LvCol;
			hList=GetDlgItem(hWnd,IDC_LIST);
			ZeroMemory(&LvCol,0);                  // Zero Members
			LvCol.mask=LVCF_TEXT|LVCF_WIDTH|LVCF_SUBITEM;    // Type of mask
			LvCol.cx=0x7;                                   // width between each coloum
			LvCol.pszText="ROM Information:";                // First Header Text
			LvCol.cx=0x100;                                   // width of column
            SendMessage(hList,LVM_SETEXTENDEDLISTVIEWSTYLE,0,LVS_EX_FULLROWSELECT);
			SendMessage(hList,LVM_INSERTCOLUMN,0,(LPARAM)&LvCol); // Insert/Show the coloum
			SendMessage(hList,LVM_SETBKCOLOR,0,(LPARAM)RGB(0,0,0)); // Insert/Show the coloum
			SendMessage(hList,LVM_SETTEXTBKCOLOR,0,(LPARAM)RGB(0,0,0));
			SendMessage(hList,LVM_SETTEXTCOLOR,0,(LPARAM)RGB(255,200,0));
			return true;
		}
		break;

		case WM_LBUTTONDOWN: 
		{
			ReleaseCapture(); 
			SendMessage(hWnd,WM_NCLBUTTONDOWN,HTCAPTION,0); 
		}
		break;

		case WM_PAINT: // constantly painting the window
		{
			return 0;
		}
		break;
		
		case WM_COMMAND: // Controling the Buttons
		{
			switch (LOWORD(wParam)) // what we pressed on?
			{ 	 
				case IDC_LOADFILE:
				{
					if(Open(hWnd,hList)==false)
					{
						break;
					}

					UpdateWindow(hWnd);
				} 
				break;

				case IDC_MENUABOUT:
				{
					MessageBox(hWnd,"GB ROM Dumper Example\nDump the entire ROM Header from Memory\n\nBy Bengi 11.02.2003","GB utility",MB_OK);
				}
				break;

				case IDC_EXIT:
				{
					EndDialog(hWnd,0); 
				}
			
			}
			break;

			case WM_CLOSE: // We colsing the Dialog
			{
				EndDialog(hWnd,0); 
			}
			break;
		}
		break;
	}
	return 0;
}




//===============================WinMain===============================================================
int WINAPI WinMain (HINSTANCE hInstance, HINSTANCE hPrevInstance, PSTR szCmdLine, int iCmdShow)
{
	hInst=hInstance;
	DialogBoxParam(hInstance, MAKEINTRESOURCE(IDD_DIALOG1), NULL, (DLGPROC)DialogProc,0);
	return 0;
}