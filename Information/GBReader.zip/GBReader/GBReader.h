#include <windows.h>
#include <commctrl.h>
#include "resource\resource.h"

#define WIN32_LEAN_AND_MEAN // this will assume smaller exe

int Open(HWND hWnd,HWND hList);
void OutDebug(HWND hWnd,char* debug,HWND hList);
bool CloseFiles(HWND hWnd, HANDLE hFile,char *Data,HANDLE hFileMap,HWND hList);
void Read_Game_Boy_Header(HWND hWnd,HWND hList,char *GB_Pointer);
